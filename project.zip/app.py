from src.services.retrieval_service import RetrievalService

service = RetrievalService(
    persist_dir=persist_dir,
    embedding_model=embedding_model,
)

if st.button("Build Index"):
    service.build_index(
        cvs_json_path="data/CVs.json",
        collection_name=collection_name,
        paragraph_config={
            "tokens_per_chunk": tokens_per_chunk,
            "chunk_overlap": chunk_overlap,
            "short_paragraph_threshold": short_paragraph_threshold,
        },
        rebuild=rebuild,
    )

if st.button("Search"):
    results = service.search(
        collection_name=collection_name,
        query=query,
        k=top_k,
        where=filter_dict,
    )
