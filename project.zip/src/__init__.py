"""
Main package initialization for the chunking evaluation system.

This package provides tools for preprocessing documents and evaluating
different text chunking strategies.
"""